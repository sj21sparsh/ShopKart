import React from "react";
import ProductsGrid from "../components/ProductsGrid";

const Shop = () => {
    return (
        <div>
            <ProductsGrid />
        </div>
    );
};

export default Shop;
