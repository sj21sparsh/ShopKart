import React from "react";
import ProductDetails from "../components/ProductDetails";

const Product = () => {
    return (
        <div>
            <ProductDetails />
        </div>
    );
};

export default Product;
