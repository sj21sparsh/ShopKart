import React from "react";
import ProductsSlider from "../components/ProductsSlider";
import Banner from "../components/Banner";
import Category from "../components/Category";
import Features from "../components/Features.jsx";

const Home = () => {
    return (
        <div>
            <Banner />
            <Category />
            <ProductsSlider />
            <ProductsSlider />
            <Features />
        </div>
    );
};

export default Home;
