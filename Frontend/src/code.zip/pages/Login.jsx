import React from "react";
import LogIn from "../components/Login";

const Login = () => {
    return (
        <div>
            <LogIn />
        </div>
    );
};

export default Login;
