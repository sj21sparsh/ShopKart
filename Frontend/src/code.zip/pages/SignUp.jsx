import React from "react";
import Signup from "../components/SignUp";

const SignUp = () => {
    return (
        <div>
            <Signup />
        </div>
    );
};

export default SignUp;
