import React, { useState } from "react";
import RelatedProducts from "./ProductsSlider";

const ProductDetails = () => {
    const Product = {
        itemId: 1,
        name: "T-Shirt",
        description: "This is a stylish T-Shirt",
        brand: "Fashion",
        material: "Cotton",
        size: ["S", "M", "L", "XL"],
        color: "Red",
        quantity: 1,
        price: 15,
        image: "https://picsum.photos/200?random=1",
    };

    const [selectedSize, setSelectedSize] = useState("");
    const [quantity, setQuantity] = useState(1);
    const [showMessage, setShowMessage] = useState(false);

    const handleAddToCart = () => {
        if (!selectedSize) {
            setShowMessage(true);
            setTimeout(() => setShowMessage(false), 2000);
            return;
        }
    };

    const quantityChange = (value) => {
        if (value === "increase") setQuantity(quantity + 1);
        else if (quantity > 1) setQuantity(quantity - 1);
    };

    return (
        <div>
            <div className="max-w-[60rem] mx-auto mb-10 px-4 py-8 grid grid-cols-1 md:grid-cols-2 gap-8 lg:space-x-15">
                <div className="flex justify-center">
                    <img
                        src={Product.image}
                        alt={Product.name}
                        className="w-full max-w-sm max-h-fit rounded shadow-lg object-cover"
                    />
                </div>

                <div className="flex flex-col justify-center space-y-4">
                    <h1 className="text-3xl font-bold text-gray-800">
                        {Product.name}
                    </h1>
                    <p className="text-gray-700">{Product.description}</p>

                    <div className="text-gray-700">
                        <p>
                            <span className="font-medium">Brand :</span>{" "}
                            {Product.brand}
                        </p>
                        <p>
                            <span className="font-medium">Material :</span>{" "}
                            {Product.material}
                        </p>
                        <p>
                            <span className="font-medium">Color :</span>{" "}
                            {Product.color}
                        </p>
                    </div>

                    <div className="text-gray-700">
                        <p className="font-medium">Sizes :</p>
                        <div className="flex space-x-2 mt-1">
                            {Product.size.map((s) => (
                                <button
                                    key={s}
                                    onClick={() => {
                                        setSelectedSize(s);
                                        setShowMessage(false);
                                    }}
                                    className={`px-3 py-1 cursor-pointer rounded text-sm ${
                                        selectedSize === s
                                            ? "text-white bg-blue-600"
                                            : "bg-gray-100"
                                    }`}
                                >
                                    {s}
                                </button>
                            ))}
                        </div>
                    </div>

                    <p className="text-2xl font-semibold text-blue-600">
                        ₹{Product.price}
                    </p>

                    <div>
                        <p className="font-medium">Quantity :</p>
                        <div className="flex items-center space-x-4 mt-2">
                            <button
                                onClick={() => quantityChange("decrease")}
                                className="border border-gray-200 rounded px-4 text-2xl font-medium cursor-pointer"
                            >
                                -
                            </button>
                            <span className="text-2xl font-semibold">
                                {quantity}
                            </span>
                            <button
                                onClick={() => quantityChange("increase")}
                                className="border border-gray-200 rounded px-4 text-2xl font-medium cursor-pointer"
                            >
                                +
                            </button>
                        </div>
                    </div>
                    {showMessage && (
                        <p className="text-red-500 text-m mb-2">
                            Please, select a size
                        </p>
                    )}
                    <button
                        onClick={handleAddToCart}
                        className={`px-6 py-3 cursor-pointer rounded-md font-semibold w-full ${
                            selectedSize
                                ? "bg-blue-600 text-white hover:bg-blue-700"
                                : "bg-gray-300 text-white"
                        }`}
                    >
                        Add to Cart
                    </button>
                </div>
            </div>
            <div>
                <RelatedProducts />
            </div>
        </div>
    );
};

export default ProductDetails;
