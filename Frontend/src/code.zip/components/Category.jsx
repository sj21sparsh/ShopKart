import React from "react";
import { NavLink } from "react-router-dom";

const Category = () => {
    return (
        <div className="container mx-auto px-4 py-10">
            <h2 className="text-2xl font-bold text-center mb-8 text-blue-800">
                Shop by Category
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <NavLink
                    to="/"
                    className="relative rounded-lg overflow-hidden group h-64 shadow"
                >
                    <img
                        src="https://picsum.photos/200?random=1"
                        alt="MEN"
                        className="w-full h-full object-cover group-hover:shadow-lg group-hover:scale-105  transition-transform duration-300"
                    />
                    <div className="absolute inset-0 lg:bg-black/40 hover:bg-black/0 flex items-center justify-center">
                        <h3 className="text-white text-xl font-semibold">
                            MEN
                        </h3>
                    </div>
                </NavLink>
                <NavLink
                    to="/"
                    className="relative rounded-lg overflow-hidden group h-64 shadow"
                >
                    <img
                        src="https://picsum.photos/400?random=2"
                        alt="WOMEN"
                        className="w-full h-full object-cover group-hover:shadow-lg group-hover:scale-105  transition-transform duration-300"
                    />
                    <div className="absolute inset-0 lg:bg-black/40 hover:bg-black/0 flex items-center justify-center">
                        <h3 className="text-white text-xl font-semibold">
                            WOMEN
                        </h3>
                    </div>
                </NavLink>
                <NavLink
                    to="/"
                    className="relative rounded-lg overflow-hidden group h-64 shadow"
                >
                    <img
                        src="https://picsum.photos/400?random=3"
                        alt="KIDS"
                        className="w-full h-full object-cover group-hover:shadow-lg group-hover:scale-105  transition-transform duration-300"
                    />
                    <div className="absolute inset-0 lg:bg-black/40 hover:bg-black/0 flex items-center justify-center">
                        <h3 className="text-white text-xl font-semibold">
                            KIDS
                        </h3>
                    </div>
                </NavLink>
            </div>
        </div>
    );
};

export default Category;
