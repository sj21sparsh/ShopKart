import React, { useState } from "react";
import cartItems from "../assets/products";

const Checkout = () => {
    const [formData, setFormData] = useState({
        fullName: "",
        email: "",
        address: "",
        city: "",
        state: "",
        postalCode: "",
        phone: "",
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
    };

    const total = cartItems.reduce(
        (acc, item) => acc + item.price * item.quantity,
        0
    );

    return (
        <div className="container mx-auto px-4 py-10">
            <h2 className="text-3xl font-bold text-center text-blue-800 mb-8">
                Checkout
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <form className="space-y-4">
                    <h3 className="text-xl font-semibold mb-4 text-gray-700">
                        Adress Details
                    </h3>
                    <input
                        type="text"
                        name="fullName"
                        placeholder="Full Name"
                        value={formData.fullName}
                        onChange={handleChange}
                        required
                        className="w-full lg:max-w-2/3 px-4 py-2 border border-gray-300 rounded focus:outline-none"
                    />
                    <input
                        type="email"
                        name="email"
                        placeholder="Email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full lg:max-w-2/3 px-4 py-2 border border-gray-300 rounded focus:outline-none"
                    />
                    <input
                        type="text"
                        name="address"
                        placeholder="Address"
                        value={formData.address}
                        onChange={handleChange}
                        required
                        className="w-full lg:max-w-2/3 px-4 py-2 border border-gray-300 rounded focus:outline-none"
                    />
                    <input
                        type="text"
                        name="city"
                        placeholder="City"
                        value={formData.city}
                        onChange={handleChange}
                        required
                        className="w-full lg:max-w-2/3 px-4 py-2 border border-gray-300 rounded focus:outline-none"
                    />
                    <input
                        type="text"
                        name="state"
                        placeholder="State"
                        value={formData.state}
                        onChange={handleChange}
                        required
                        className="w-full lg:max-w-2/3 px-4 py-2 border border-gray-300 rounded focus:outline-none"
                    />
                    <input
                        type="text"
                        name="postalCode"
                        placeholder="Postal Code"
                        value={formData.postalCode}
                        onChange={handleChange}
                        required
                        className="w-full lg:max-w-2/3 px-4 py-2 border border-gray-300 rounded focus:outline-none"
                    />
                    <input
                        type="text"
                        name="phone"
                        placeholder="Phone Number"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                        className="w-full lg:max-w-2/3 px-4 py-2 border border-gray-300 rounded focus:outline-none"
                    />
                </form>

                <div className="bg-white shadow-md rounded-md p-6">
                    <h3 className="text-xl font-semibold mb-4 text-gray-700">
                        Order Summary
                    </h3>
                    <div className="space-y-4">
                        {cartItems.map((item) => (
                            <div
                                key={item.itemId}
                                className="flex items-center justify-between"
                            >
                                <div className="flex items-center space-x-4">
                                    <img
                                        src={item.image}
                                        alt={item.name}
                                        className="w-16 h-16 object-cover rounded"
                                    />
                                    <div>
                                        <p className="font-medium text-gray-800">
                                            {item.name}
                                        </p>
                                        <p className="text-sm text-gray-500">
                                            Qty : {item.quantity} | Size :{" "}
                                            {item.size[0]} | Color :{" "}
                                            {item.color}
                                        </p>
                                    </div>
                                </div>
                                <p className="text-blue-700 font-semibold">
                                    ₹{item.price * item.quantity}
                                </p>
                            </div>
                        ))}
                    </div>
                    <div className="border-t pt-4 m-4 flex justify-between text-lg font-semibold">
                        <span>Total :</span>
                        <span className="text-blue-800">₹{total}</span>
                    </div>
                    <div className="m-4 flex justify-between text-lg">
                        <span className="font-semibold">Payment Mode :</span>
                        <span>COD</span>
                    </div>
                    <button
                        onClick={handleSubmit}
                        className="w-full font-semibold cursor-pointer bg-blue-600 text-white py-3 rounded hover:bg-blue-700"
                    >
                        Place Order
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Checkout;
