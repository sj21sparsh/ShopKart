import React, { useState } from "react";

const LogIn = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
    };

    return (
        <div className="h-screen flex justify-center bg-gray-100 px-4 border-b-2 border-white">
            <div className="mt-20 max-h-[25rem] max-w-md w-full bg-white p-8 rounded-lg shadow-md">
                <h2 className="text-2xl font-bold text-center text-blue-700 mb-6">
                    Login
                </h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-black mb-1">Email</label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="Your Email Id"
                            required
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none"
                        />
                    </div>
                    <div>
                        <label className="block text-black mb-1">
                            Password
                        </label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Your Password"
                            required
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none"
                        />
                    </div>
                    <button
                        type="submit"
                        className="w-full font-medium bg-blue-600 text-white py-2 rounded-md cursor-pointer hover:bg-blue-700 transition-colors"
                    >
                        Sign In
                    </button>
                </form>
                <p className="text-sm text-center text-gray-500 mt-4">
                    Don't have an account?{" "}
                    <span className="text-blue-600 font-medium cursor-pointer hover:underline">
                        Sign Up
                    </span>
                </p>
            </div>
        </div>
    );
};

export default LogIn;
