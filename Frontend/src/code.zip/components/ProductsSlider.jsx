import React, { useRef } from "react";
import Products from "../assets/products";
import { HiChevronLeft, HiChevronRight } from "react-icons/hi";

const ProductsSlider = () => {
    const scrollRef = useRef(null);

    const scrollLeft = () => {
        scrollRef.current.scrollBy({ left: -300 });
    };

    const scrollRight = () => {
        scrollRef.current.scrollBy({ left: 300 });
    };

    return (
        <div className="px-4 lg:px-8 py-6 relative">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-blue-800 text-2xl font-bold">
                    Latest Collection
                </h2>
                <div className="space-x-2">
                    <button
                        onClick={scrollLeft}
                        className="p-2 bg-gray-200 hover:bg-gray-300 rounded cursor-pointer"
                    >
                        <HiChevronLeft size={20} />
                    </button>
                    <button
                        onClick={scrollRight}
                        className="p-2 bg-gray-200 hover:bg-gray-300 rounded cursor-pointer"
                    >
                        <HiChevronRight size={20} />
                    </button>
                </div>
            </div>

            <div
                ref={scrollRef}
                className="flex gap-4 lg:gap-10 overflow-x-auto scroll-smooth no-scrollbar"
            >
                {Products.map((product) => (
                    <div
                        key={product.itemId}
                        className="min-w-[50%] md:min-w-[25%] lg:min-w-[15%] cursor-pointer bg-white shadow rounded-md p-2"
                    >
                        <img
                            src={product.image}
                            alt={product.name}
                            className="w-full max-h-55 object-cover rounded"
                        />
                        <h4 className="text-sm mt-2 font-semibold">
                            {product.name}
                        </h4>
                        <p className="text-xs text-gray-500">
                            Size : {product.size[0]} | Color : {product.color}
                        </p>
                        <p className="text-blue-700 font-bold text-xl my-2">
                            ₹{product.price}
                        </p>
                        <button className="w-full text-white bg-blue-500 hover:bg-blue-600 cursor-pointer p-1 rounded">
                            Add to Cart
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ProductsSlider;
