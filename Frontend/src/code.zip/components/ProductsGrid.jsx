import React from "react";
import products from "../assets/products";

const ProductsGrid = () => {
    return (
        <div className="container mx-auto px-4 py-10">
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 cursor-pointer">
                {products.map((product) => (
                    <div
                        key={product.itemId}
                        className="bg-white shadow-md rounded-md p-1 lg:p-4"
                    >
                        <img
                            src={product.image}
                            alt={product.name}
                            className="w-full max-h-55 object-cover rounded"
                        />
                        <h4 className="text-lg font-semibold mt-2">
                            {product.name}
                        </h4>
                        <p className="text-sm text-gray-600">
                            Size: {product.size[0]} | Color: {product.color}
                        </p>
                        <p className="text-blue-700 font-bold text-xl my-2">
                            ₹{product.price}
                        </p>
                        <button className="w-full bg-blue-600 text-white font-semibold py-2 cursor-pointer rounded hover:bg-blue-700 transition-colors">
                            Add to Cart
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ProductsGrid;
