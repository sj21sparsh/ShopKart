import React, { useState } from "react";

const Signup = () => {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirmError, setConfirmError] = useState("");

    const handlePassword = (e) => {
        const newPassword = e.target.value;
        setPassword(newPassword);

        if (newPassword.length < 8) {
            setPasswordError("Password should be atleast 8 characters");
        } else {
            setPasswordError("");
        }

        if (confirmPassword && newPassword !== confirmPassword) {
            setConfirmError("Passwords do not match");
        } else {
            setConfirmError("");
        }
    };

    const handleConfirmPassword = (e) => {
        const newConfirmPassword = e.target.value;
        setConfirmPassword(newConfirmPassword);

        if (password !== newConfirmPassword) {
            setConfirmError("Passwords do not match");
        } else {
            setConfirmError("");
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (password.length < 8) {
            setErrorMessage("Password should be atleast 8 characters");
            return;
        }
        if (password !== confirmPassword) {
            setErrorMessage("Passwords do not match");
            return;
        }
    };

    return (
        <div className="h-screen flex justify-center bg-gray-100 px-4 border-b-2 border-white">
            <div className="mt-10 max-h-[36rem] max-w-md w-full bg-white p-8 rounded-lg shadow-md">
                <h2 className="text-2xl font-bold text-center text-blue-700 mb-6">
                    Create an Account
                </h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-black mb-1">Name</label>
                        <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="Your Name"
                            required
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none"
                        />
                    </div>
                    <div>
                        <label className="block text-black mb-1">Email</label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="Your Email Id"
                            required
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none"
                        />
                    </div>
                    <div>
                        <label className="block text-black mb-1">
                            Password
                        </label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => {
                                handlePassword(e);
                            }}
                            placeholder="Your Password"
                            required
                            className={`w-full px-4 py-2 border ${
                                passwordError &&
                                "Password should be atleast 8 characters"
                                    ? "border-red-500"
                                    : "border-gray-300"
                            } rounded-md focus:outline-none`}
                        />
                        {passwordError && (
                            <p className="text-red-500 text-sm mt-1">
                                {passwordError}
                            </p>
                        )}
                    </div>
                    <div>
                        <label className="block text-black mb-1">
                            Confirm Password
                        </label>
                        <input
                            type="password"
                            value={confirmPassword}
                            onChange={(e) => {
                                handleConfirmPassword(e);
                            }}
                            placeholder="Re-enter Password"
                            required
                            className={`w-full px-4 py-2 border ${
                                confirmError && "Passwords do not match"
                                    ? "border-red-500"
                                    : "border-gray-300"
                            } rounded-md focus:outline-none`}
                        />
                        {confirmError && (
                            <p className="text-red-500 text-sm mt-1">
                                {confirmError}
                            </p>
                        )}
                    </div>
                    <button
                        type="submit"
                        className="w-full font-medium bg-blue-600 text-white py-2 rounded-md cursor-pointer hover:bg-blue-700 transition-colors"
                    >
                        Sign Up
                    </button>
                </form>
                <p className="text-sm text-center text-gray-500 mt-4">
                    Already have an account?{" "}
                    <span className="text-blue-600 font-medium cursor-pointer hover:underline">
                        LogIn
                    </span>
                </p>
            </div>
        </div>
    );
};

export default Signup;
