import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import CartSlider from "./CartSlider";
import {
    HiOutlineUser,
    HiOutlineShoppingBag,
    HiBars3BottomRight,
    HiMagnifyingGlass,
    HiPhone,
} from "react-icons/hi2";
import { HiX } from "react-icons/hi";

const Navbar = () => {
    const [searchTerm, setSearchTerm] = useState("");
    const [showMobileSearch, setShowMobileSearch] = useState(false);
    const [isCartOpen, setIsCartOpen] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    useEffect(() => {
        if (isMobileMenuOpen) {
            document.body.classList.add("overflow-hidden");
        } else {
            document.body.classList.remove("overflow-hidden");
        }
        return () => document.body.classList.remove("overflow-hidden");
    }, [isMobileMenuOpen]);

    const handleSearch = (e) => {
        e.preventDefault();
        setSearchTerm("");
        setShowMobileSearch(false);
    };

    return (
        <div className="sticky top-0 w-full z-50 bg-white border-b border-gray-200">
            <nav className="container mx-auto flex items-center justify-between p-4">
                <div>
                    <NavLink
                        to="/"
                        className="text-blue-800 text-2xl font-bold"
                    >
                        ShopKart
                    </NavLink>
                </div>
                <form
                    onSubmit={handleSearch}
                    className="hidden md:w-[25rem] md:flex lg:w-1/3"
                >
                    <input
                        type="text"
                        placeholder="Search Outfits"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full px-4 py-1.5 rounded-l-md bg-gray-100 text-black outline-none"
                    />
                    <button
                        type="submit"
                        className="bg-gray-300 hover:bg-gray-400 cursor-pointer px-4 py-1.5 rounded-r-md"
                    >
                        <HiMagnifyingGlass />
                    </button>
                </form>
                <div className="hidden lg:flex space-x-7">
                    <NavLink
                        to="/"
                        className="text-gray-600 hover:text-gray-800 text-xl font-medium"
                    >
                        HOME
                    </NavLink>
                    <NavLink
                        to="/"
                        className="text-gray-600 hover:text-gray-800 text-xl font-medium"
                    >
                        SHOP
                    </NavLink>
                    <NavLink
                        to="/"
                        className="text-gray-600 hover:text-gray-800 text-xl font-medium"
                    >
                        MEN
                    </NavLink>
                    <NavLink
                        to="/"
                        className="text-gray-600 hover:text-gray-800 text-xl font-medium"
                    >
                        WOMEN
                    </NavLink>
                    <NavLink
                        to="/"
                        className="text-gray-600 hover:text-gray-800 text-xl font-medium"
                    >
                        KIDS
                    </NavLink>
                </div>
                <div className="flex items-center space-x-5">
                    <button
                        className="md:hidden h-6 w-6 text-gray-800 text-2xl"
                        onClick={() => setShowMobileSearch(!showMobileSearch)}
                    >
                        <HiMagnifyingGlass />
                    </button>
                    <button
                        onClick={() => setIsCartOpen(true)}
                        className="relative cursor-pointer"
                    >
                        <HiOutlineShoppingBag className="h-6 w-6 text-gray-600 hover:text-gray-800" />
                        <span className="absolute -top-1 bg-blue-600 text-white text-xs rounded-full px-2 py-0.5">
                            2
                        </span>
                    </button>
                    <NavLink to="/profile">
                        <HiOutlineUser className="h-6 w-6 text-gray-600 hover:text-gray-800 cursor-pointer" />
                    </NavLink>
                    <button>
                        <HiBars3BottomRight
                            onClick={() =>
                                setIsMobileMenuOpen(!isMobileMenuOpen)
                            }
                            className="lg:hidden h-6 w-6 text-gray-800"
                        />
                    </button>
                </div>
            </nav>

            <CartSlider isCartOpen={isCartOpen} setIsCartOpen={setIsCartOpen} />

            <div
                className={`fixed inset-0 z-10 bg-black/20 ${
                    isMobileMenuOpen ? "translate-x-0" : "translate-x-full"
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
            ></div>
            <div
                className={`fixed flex flex-col top-0 right-0 h-full w-2/3 md:w-[20rem] bg-white shadow-lg z-20 transform transition-transform duration-300 ${
                    isMobileMenuOpen ? "translate-x-0" : "translate-x-full"
                }`}
            >
                <div className="flex items-center justify-between px-4 p-4 border-b">
                    <h2 className="text-lg font-semibold">Menu</h2>
                    <button
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="text-2xl text-gray-600 cursor-pointer"
                    >
                        <HiX />
                    </button>
                </div>
                <div className="flex flex-col mt-8">
                    <NavLink
                        to="/"
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="block text-gray-700 font-medium text-lg p-2 mx-auto"
                    >
                        HOME
                    </NavLink>
                    <NavLink
                        to="/"
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="block text-gray-700 font-medium text-lg p-2 mx-auto"
                    >
                        SHOP
                    </NavLink>
                    <NavLink
                        to="/"
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="block text-gray-700 font-medium text-lg p-2 mx-auto"
                    >
                        MEN
                    </NavLink>
                    <NavLink
                        to="/"
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="block text-gray-700 font-medium text-lg p-2 mx-auto"
                    >
                        WOMEN
                    </NavLink>
                    <NavLink
                        to="/"
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="block text-gray-700 font-medium text-lg p-2 mx-auto"
                    >
                        KIDS
                    </NavLink>
                </div>
                <div className="flex flex-col">
                    <NavLink
                        to="/"
                        className="text-gray-600 font-medium mt-4 mb-2 mx-auto"
                    >
                        Contact Us
                    </NavLink>
                    <NavLink
                        to="/"
                        className="text-gray-600 font-medium my-2 mx-auto"
                    >
                        About Us
                    </NavLink>
                    <div className="flex items-center mx-auto text-gray-600 font-medium my-2">
                        <HiPhone />
                        <span className="mx-2">+91 6377653078</span>
                    </div>
                </div>
            </div>

            {showMobileSearch && (
                <div className="md:hidden px-4 mb-2">
                    <form onSubmit={handleSearch} className="flex w-full">
                        <input
                            type="text"
                            placeholder="Search Outfits"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full px-4 py-2 rounded-l-sm bg-gray-100 text-black outline-none"
                        />
                        <button
                            type="submit"
                            className="bg-gray-300 px-4 py-2 rounded-r-sm"
                        >
                            <HiMagnifyingGlass />
                        </button>
                    </form>
                </div>
            )}
        </div>
    );
};

export default Navbar;
