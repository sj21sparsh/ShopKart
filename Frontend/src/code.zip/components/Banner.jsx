import React from "react";

const Banner = () => {
    return (
        <div
            className="relative bg-cover bg-center h-[50vh] w-full"
            style={{
                backgroundImage:
                    "url('https://picsum.photos/1600/600?grayscale')",
            }}
        >
            <div className="absolute inset-0 flex flex-col justify-center items-center text-center">
                <h1 className="text-white text-3xl md:text-5xl font-bold mb-2">
                    Discover Your Style
                </h1>
                <p className="text-white md:text-lg mb-4">
                    Latest trends in fashion at exciting prices
                </p>
                <button className="bg-blue-600 text-white cursor-pointer font-semibold py-2 px-6 rounded-md mt-10">
                    Shop Now
                </button>
            </div>
        </div>
    );
};

export default Banner;
